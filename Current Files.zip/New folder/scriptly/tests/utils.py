import os

from django.core.files.storage import default_storage

from .. import settings as scriptly_settings


def get_subparser_form_slug(script_version, param):
    return script_version.scriptparameter_set.get(script_param=param).form_slug


def save_script_path(script_path):
    filename = os.path.split(script_path)[1]
    filename = os.path.join(scriptly_settings.SCRIPTLY_SCRIPT_DIR, filename)
    with open(script_path) as script_handle:
        path = default_storage.save(filename, script_handle)
    return path
