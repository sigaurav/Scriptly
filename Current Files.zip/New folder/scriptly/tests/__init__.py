__author__ = "chris"
import os

os.environ["TESTING"] = "True"
