from __future__ import unicode_literals
import os

from django.core.files import File

BASE_DIR = os.path.split(__file__)[0]
SCRIPTLY_TEST_SCRIPTS = os.path.join(BASE_DIR, "scripts")
SCRIPTLY_TEST_DATA = os.path.join(BASE_DIR, "data")
SCRIPTLY_TEST_REMOTE_STORAGE_DIR = "remote_storage"
SCRIPTLY_TEST_REMOTE_STORAGE_PATH = os.path.join(BASE_DIR, "media", "remote_storage")

# Because forms are input as lists by Django, all attributes here need to be
# list like as well. The MultiValueDict/QueryDict get method assumes a list and
# will take the first element in validation (so for a string like 'ATAT' it will
# provide 'A').
SCRIPT_DATA = {
    "translate": {
        "data": {
            "scriptly_type": ["1"],
            "job_name": ["abc"],
            "sequence": ["ATATATATATA"],
            "frame": ["+3"],
            "out": ["abc"],
        }
    },
    "choices": {
        "data": {
            "scriptly_type": ["1"],
            "job_name": ["abc"],
            "two_choices": [1, 2],
        },
        "files": {
            "multiple_file_choices": [
                File(open(os.path.join(SCRIPTLY_TEST_SCRIPTS, "choices.py"), "rb")),
                File(open(os.path.join(SCRIPTLY_TEST_SCRIPTS, "crop.py"), "rb")),
            ]
        },
    },
    "without_args": {
        "data": {
            "job_name": ["abc"],
        }
    },
}
