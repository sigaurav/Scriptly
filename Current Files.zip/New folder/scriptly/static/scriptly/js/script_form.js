console.log("✅ script_form.js loaded!");

document.addEventListener("DOMContentLoaded", function () {
    console.log("✅ DOM ready");

    // Safely unbind and bind the submit handler
    $(document).off('submit', '.script-form').on('submit', '.script-form', function (e) {
        e.preventDefault();
        console.log("📤 Intercepted form submit");

        const $form = $(this);
        const formData = new FormData(this);

        // Remove any existing progress bar
        $('.scriptly-progress').remove();

        const progressHTML = `
            <div class="scriptly-progress">
                <div class="progress">
                    <div class="progress-bar progress-bar-striped active" style="width: 100%">
                        Submitting Job...
                    </div>
                </div>
            </div>`;
        $form.before(progressHTML);

        $.ajax({
            url: $form.attr('action'),
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function (data) {
                $('.scriptly-progress').remove();

                if (data.valid) {
                    console.log("✅ AJAX success", data);

                    const modalHTML = `
                      <div class="modal fade" id="jobCompleteModal" tabindex="-1" role="dialog">
                        <div class="modal-dialog" role="document">
                          <div class="modal-content">
                            <div class="modal-header bg-success text-white">
                              <h4 class="modal-title">✅ Job Submitted</h4>
                            </div>
                            <div class="modal-body">
                              <p>Your job has been submitted successfully.</p>
                              <p><strong>Job ID:</strong> ${data.job_id}</p>
                            </div>
                            <div class="modal-footer">
                              <a href="${data.redirect}" class="btn btn-primary">View Job</a>
                              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            </div>
                          </div>
                        </div>
                      </div>`;

                    $('#jobCompleteModal').remove();
                    $('body').append(modalHTML);
                    $('#jobCompleteModal').modal('show');
                } else {
                    alert("❌ Submission failed.");
                }
            },
            error: function (xhr) {
                $('.scriptly-progress').remove();
                console.error("❌ Server error", xhr.responseText);
                alert("❌ Server error.");
            }
        });
    });
});
