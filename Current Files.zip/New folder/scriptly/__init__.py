default_app_config = "scriptly.apps.ScriptlyConfig"
